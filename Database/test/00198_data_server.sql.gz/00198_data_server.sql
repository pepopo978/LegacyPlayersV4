/*!40101 SET NAMES utf8 */;

USE `main_test`;

INSERT INTO `data_server` (`id`, `expansion_id`, `server_name`, `owner`, `patch`) VALUES (22, 1, "Turtle WoW", NULL, "1.12");
