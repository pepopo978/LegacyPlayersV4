ALTER TABLE `main`.`data_server`
	ADD COLUMN `patch` VARCHAR(20) NOT NULL AFTER `owner`;

delete from `main`.`data_server`;
INSERT INTO `main`.`data_server` (`id`, `expansion_id`, `server_name`, `owner`, `patch`) VALUES (22, 1, "Turtle WoW", NULL, "1.12");